# sha224
#### sha224 implementation in python

## Resources:
[FIPS-180-4](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.180-4.pdf)
[sha224 examples](https://csrc.nist.gov/csrc/media/projects/cryptographic-standards-and-guidelines/documents/examples/sha224.pdf)

## Usage:
Import hash class from sha224.py:
```python
from sha224 import hash as sha224
```
Call sha224 function with message and mode as parameters;
Mode indicates format of message:
```python
sha224.sha224('abc', 0)
```
Modes:
```python
# 0 = ASCII
# 1 = Integer (Base 10)
# 2 = Hexadecimal (Base 16)
# 3 = Binary (Base 2)
# 4 = Octal (Base 8)
# 5 = From file
```