# sha512
#### sha512 implementation in python

## Resources:
[FIPS-180-4](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.180-4.pdf)
[sha512 examples](https://csrc.nist.gov/csrc/media/projects/cryptographic-standards-and-guidelines/documents/examples/sha512.pdf)

## Usage:
Import hash class from sha512.py:
```python
from SHA512 import hash as sha512
```
Call sha512 function with message and mode as parameters;
Mode indicates format of message:
```python
sha512.sha512('abc', 0)
```
Modes:
```python
# 0 = ASCII
# 1 = Integer (Base 10)
# 2 = Hexadecimal (Base 16)
# 3 = Binary (Base 2)
# 4 = Octal (Base 8)
# 5 = From file
```