# sha512/224
#### sha512/224 implementation in python

## Resources:
[FIPS-180-4](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.180-4.pdf)
[sha512_224 examples](https://csrc.nist.gov/csrc/media/projects/cryptographic-standards-and-guidelines/documents/examples/sha512_224.pdf)

## Usage:
Import hash class from sha512_224.py:
```python
from SHA512_224 import hash as sha512_224
```
Call sha512_224 function with message and mode as parameters;
Mode indicates format of message:
```python
sha512_224.sha512_224('abc', 0)
```
Modes:
```python
# 0 = ASCII
# 1 = Integer (Base 10)
# 2 = Hexadecimal (Base 16)
# 3 = Binary (Base 2)
# 4 = Octal (Base 8)
# 5 = From file
```