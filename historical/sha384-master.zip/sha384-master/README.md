# sha384
#### sha384 implementation in python

## Resources:
[FIPS-180-4](https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.180-4.pdf)
[sha384 examples](https://csrc.nist.gov/csrc/media/projects/cryptographic-standards-and-guidelines/documents/examples/sha384.pdf)

## Usage:
Import hash class from sha384.py:
```python
from SHA384 import hash as sha384
```
Call sha384 function with message and mode as parameters;
Mode indicates format of message:
```python
sha384.sha384('abc', 0)
```
Modes:
```python
# 0 = ASCII
# 1 = Integer (Base 10)
# 2 = Hexadecimal (Base 16)
# 3 = Binary (Base 2)
# 4 = Octal (Base 8)
# 5 = From file
```